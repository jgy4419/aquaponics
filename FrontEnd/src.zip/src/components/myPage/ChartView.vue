<template>
  <div style="width:75vw;">
    <canvas id = "chart" class="chart"/>
  </div>
</template>

<script>
import { Chart, registerables } from 'chart.js';
// import axios from 'axios';
Chart.register(...registerables);
export default {
  methods: {
    fillData(){
      const ctx = document.getElementById('chart').getContext('2d');
      this.myChart = new Chart(ctx, {
          type: 'line',
          data: {
            labels: ['221001', '221002', '221003', '221001', '221002', '221003'],
            datasets: [
              {
                label: '습도',
                data: [5, 8, 3, 5, 8, 3],
                backgroundColor: '#3e95cd',
                borderColor: 'rgb(7, 95, 95)',
                postDetailChartState: 0,
                borderWidth: 1
              },
              {
                label: '온도',
                data: [7, 15, 8, 7, 15, 8],
                backgroundColor: '#8e5ea2',
                borderColor: 'rgb(7, 95, 95)',
                postDetailChartState: 0,
                borderWidth: 1
              },
              {
                label: '조도',
                data: [20, 3, 5, 8, 25, 4],
                backgroundColor: '#3cba9f',
                borderColor: 'rgb(7, 95, 95)',
                postDetailChartState: 0,
                borderWidth: 1
              }
            ]
          },
          options: {
            title: {
              display: true,
              responsive: false,
              text: 'World population per region (in millions)'
            },
            animation: {
              animateScale: true,
              animateRotate: true,
            }
          },
        }
      );
    }
  },
  mounted(){
    this.fillData();
  },
  data(){
    return{
      myChart: null
    };
  }
}
</script>

<style lang="scss" scoped>
div{
  color: rgba(219, 252, 171, 0.2)
}
</style>