// const webcamElement = document.getElementById('webcam'); 
// const canvasElement = document.getElementById('canvas');
// const snapSoundElement = document.getElementById('snapSound');
// const webcam = new Webcam(webcamElement, 'user', canvasElement, snapSoundElement);

// // 웹캠 보여주는 코드
// webcam.start()
// .then(res => {
//   console.log('Webcam started.');
// })
// .catch(err => {
//   console.log(err);
// })

// let picture = webcam.snap();
// let btn = document.querySelector('.stopBtn');
// btn.addEventListener('click', function(){
//   webcam.stop(); // webCam 꺼주는 기능.
// })
// let start = document.querySelector('.startBtn');

// start.addEventListener('click', function(){
//   webcam.start();
// })